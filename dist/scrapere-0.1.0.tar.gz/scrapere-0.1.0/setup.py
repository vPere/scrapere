from setuptools import find_packages, setup

setup(
    name='scrapere',
    packages=find_packages(),
    version='0.1.0',
    description='Small set of my web scraping python tools',
    author='vPere',
    license='MIT',
    install_requires=[
        'requests',
        'beautifulsoup4',
        'colorama',
        'emoji'
    ],
    include_package_data=True,
    package_data={'': ['*.txt']},
)
