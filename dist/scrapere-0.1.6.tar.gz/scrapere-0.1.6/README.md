# Scraping libary

This is a simple toolbox for scraping info from websites which includes methods for generating headers with a random user agent picked from a list of more than 24k user agents, a method for waiting a random time between 1 and 3 seconds, a progress bar for it to look cool ;) and a couple of methods that will help you retreive email addresses and spanish phone numbers from a given url.

As this package may be useful for a bunch of legitimate and non-legitimate use cases, I'm not responsible of whatever you do with it.


## Version 0.1.6 issues:
- There are no tests...
- scrap_phones() only works for spanish phone numbers

As this is my first python package, I might not mantain it, so better try finding another one...